train and test data for shuttle dataset
