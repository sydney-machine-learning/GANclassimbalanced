the code of the proposed method of SMOTified-GAN
